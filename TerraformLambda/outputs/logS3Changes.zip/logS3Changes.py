import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

def logS3Changes(event,context):
    print("Welcome to terraform")
    logger.info('## ENVIRONMENT VARIABLES')
    logger.info(os.environ)
    logger.debug('## EVENT')
    logger.debug(event)